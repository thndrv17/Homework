//
//  NewViewController.swift
//  3Views
//
//  Created by User-UAM on 8/31/24.
//

import UIKit

class NewViewController: UIViewController {
    let myCustomModel: [MyCustomStruct] = [
        MyCustomStruct(myImage: UIImage(named: "Cerro Negro")!, myLabel: "Cerro Negro"),
        MyCustomStruct(myImage: UIImage(named: "Corn Island")!, myLabel: "Corn Island"),
        MyCustomStruct(myImage: UIImage(named: "El Castillo")!, myLabel: "El Castillo"),
        MyCustomStruct(myImage: UIImage(named: "Laguna de Apoyo")!, myLabel: "Laguna de Apoyo"),
        MyCustomStruct(myImage: UIImage(named: "Lake Nicaragua")!, myLabel: "Lake Nicaragua"),
        MyCustomStruct(myImage: UIImage(named: "Leon")!, myLabel: "Leon"),
        MyCustomStruct(myImage: UIImage(named: "Granada")!, myLabel: "Granada"),
        MyCustomStruct(myImage: UIImage(named: "Las Isletas")!, myLabel: "Las Isletas"),
        MyCustomStruct(myImage: UIImage(named: "Ometepe")!, myLabel: "Ometepe Island"),
        
        
    ]
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myCollectionView.register(UINib(nibName: "TourCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell")
        
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
    }
    
}
extension NewViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        myCustomModel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! TourCollectionViewCell
        
        
        cell.config(data: myCustomModel[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(myCustomModel[indexPath.row].myLabel)
    }
    
    
}
