//
//  LoginViewController.swift
//  3Views
//
//  Created by User-UAM on 8/30/24.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad()
    
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func botonPresionado(_ sender: Any)
    
    {
        let HomeViewController = HomeViewController(nibName: "HomeViewController", bundle: nil)
        self.navigationController?.pushViewController(HomeViewController, animated: true)
    }
    
    
    
}


