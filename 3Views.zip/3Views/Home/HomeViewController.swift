//
//  HomeViewController.swift
//  3Views
//
//  Created by User-UAM on 8/27/24.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func botonPresionado2(_ sender: Any)
    {
        let NewViewController = NewViewController(nibName: "NewViewController", bundle: nil)
        self.navigationController?.pushViewController(NewViewController, animated: true)
    }
    
}
