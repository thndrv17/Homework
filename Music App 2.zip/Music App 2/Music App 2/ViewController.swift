//
//  ViewController.swift
//  Music App 2
//
//  Created by User-UAM on 8/15/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Circle: UIImageView!

    @IBOutlet weak var Caravan: UIImageView!
    
    @IBOutlet weak var Shade: UIImageView!
    
    @IBOutlet weak var Next: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Circle.layer.cornerRadius = Circle.frame.height / 2
        Circle.layer.masksToBounds = true
        Caravan.layer.cornerRadius = Caravan.frame.height / 2
        Shade.layer.cornerRadius = Shade.frame.height / 2
        Next.layer.cornerRadius = Next.frame.height / 2
        
    }


}

